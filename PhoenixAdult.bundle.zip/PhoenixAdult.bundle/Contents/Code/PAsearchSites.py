import siteBrazzers
#import siteBlacked
import siteNaughtyAmerica
#import siteVixen
import siteXart
import siteBangBros
#import siteTushy
import siteRealityKings
import siteTeamSkeet
import sitePorndoePremium
import siteLegalPorno
import siteMofos
import siteBabes
import siteGloryHoleSecrets
import siteNewSensations
import siteTwistys
import siteSpizoo
import sitePrivate
import siteDigitalPlayground
import networkSexyHub
import networkFPN
import networkSteppedUp
import networkGammaEnt
import networkDogfart
import siteJulesJordan
import siteManuelFerrara
import siteTheAssFactory
import siteSpermSwallowers
import networkDDFNetwork
import networkPerfectGonzo
import networkPornFidelity
import networkBadoinkVR
import siteVRBangers
import siteSexBabesVR
import siteWankzVR
import siteMilfVR
import siteJoymii
import networkPornPros
import networkStrike3
import networkKink
import networkNubiles

searchSites = [None] * 548
searchSites[1] = ["Blacked com","Blacked","https://www.blacked.com","https://www.blacked.com/search?q="]
searchSites[0] = ["Blackedraw com","BlackedRaw","https://www.blackedraw.com","https://www.blackedraw.com/search?q="]
searchSites[2] = ["Brazzers.com","Brazzers","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[4] = ["Blacked","Blacked","https://www.blacked.com","https://www.blacked.com/search?q="]
searchSites[3] = ["Blackedraw","BlackedRaw","https://www.blackedraw.com","https://www.blackedraw.com/search?q="]
searchSites[5] = ["My Friends Hot Mom","My Friends Hot Mom","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[6] = ["My First Sex Teacher","My First Sex Teacher","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[7] = ["Seduced By A Cougar","Seduced By A Cougar","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[8] = ["My Daughters Hot Friend","My Daughters Hot Friend","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[9] = ["My Wife is My Pornstar","My Wife is My Pornstar","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[10] = ["Tonights Girlfriend Classic","Tonights Girlfriend Classic","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[11] = ["Wives on Vacation","Wives on Vacation","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[12] = ["My Sisters Hot Friend","My Sisters Hot Friend","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[13] = ["Naughty Weddings","Naughty Weddings","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[14] = ["Dirty Wives Club","Dirty Wives Club","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[15] = ["My Dads Hot Girlfriend","My Dads Hot Girlfriend","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[16] = ["My Girl Loves Anal","My Girl Loves Anal","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[17] = ["Lesbian Girl on Girl","Lesbian Girl on Girl","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[18] = ["Naughty Office","Naughty Office","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[19] = ["I have a Wife","I have a Wife","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[20] = ["Naughty Bookworms","Naughty Bookworms","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[21] = ["Housewife 1 on 1","Housewife 1 on 1","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[22] = ["My Wifes Hot Friend","My Wifes Hot Friend","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[23] = ["Latin Adultery","Latin Adultery","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[24] = ["Ass Masterpiece","Ass Masterpiece","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[25] = ["2 Chicks Same Time","2 Chicks Same Time","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[26] = ["My Friends Hot Girl","My Friends Hot Girl","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[27] = ["Neighbor Affair","Neighbor Affair","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[28] = ["My Girlfriends Busty Friend","My Girlfriends Busty Friend","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[29] = ["Naughty Athletics","Naughty Athletics","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[30] = ["My Naughty Massage","My Naughty Massage","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[31] = ["Fast Times","Fast Times","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[32] = ["The Passenger","The Passenger","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[33] = ["Milf Sugar Babes Classic","Milf Sugar Babes Classic","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[34] = ["Perfect Fucking Strangers Classic","Perfect Fucking Strangers Classic","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[35] = ["Asian 1 on 1","Asian 1 on 1","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[36] = ["American Daydreams","American Daydreams","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[37] = ["SoCal Coeds","SoCal Coeds","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[38] = ["Naughty Country Girls","Naughty Country Girls","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[39] = ["Diary of a Milf","Diary of a Milf","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[40] = ["Naughty Rich Girls","Naughty Rich Girls","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[41] = ["My Naughty Latin Maid","My Naughty Latin Maid","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[42] = ["Naughty America","Naughty America","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[43] = ["Diary of a Nanny","Diary of a Nanny","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[44] = ["Naughty Flipside","Naughty Flipside","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[45] = ["Live Party Girl","Live Party Girl","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[46] = ["Live Naughty Student","Live Naughty Student","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[47] = ["Live Naughty Secretary","Live Naughty Secretary","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[48] = ["Live Gym Cam","Live Gym Cam","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[49] = ["Live Naughty Teacher","Live Naughty Teacher","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[50] = ["Live Naughty Milf","Live Naughty Milf","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[51] = ["Live Naughty Nurse","Live Naughty Nurse","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[52] = ["Vixen","Vixen","http://www.vixen.com","http://www.vixen.com/search?q="]
searchSites[53] = ["Girlsway","Girlsway","https://www.girlsway.com","http://www.girlsway.com/en/search/"]
searchSites[54] = ["Moms in Control","Moms in Control","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[55] = ["Pornstars Like It Big","Pornstars Like It Big","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[56] = ["Big Tits at Work","Big Tits at Work","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[57] = ["Big Tits at School","Big Tits at School","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[58] = ["Baby Got Boobs","Baby Got Boobs","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[59] = ["Real Wife Stories","Real Wife Stories","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[60] = ["Teens Like It Big","Teens Like It Big","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[61] = ["ZZ Series","ZZ Series","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[62] = ["Mommy Got Boobs","Mommy Got Boobs","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[63] = ["Milfs Like It Big","Milfs Like It Big","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[64] = ["Big Tits in Uniform","Big Tits in Uniform","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[65] = ["Doctor Adventures","Doctor Adventures","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[66] = ["BrazzersExxtra","Exxtra","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[67] = ["Big Tits in Sports","Big Tits in Sports","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[68] = ["Big Butts like it big","Big Butts like it big","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[69] = ["Big Wet Butts","Big Wet Butts","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[70] = ["Dirty Masseur","Dirty Masseur","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[71] = ["Hot and Mean","Hot and Mean","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[72] = ["Shes Gonna Squirt","Shes Gonna Squirt","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[73] = ["Asses In Public","Asses In Public","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[74] = ["Busty Z","Busty Z","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[75] = ["Busty and Real","Busty and Real","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[76] = ["Hot Chicks Big Asses","Hot Chicks Big Asses","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[77] = ["CFNM Clothed Female Male Nude","CFNM Clothed Female Male Nude","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[78] = ["Teens Like It Black","Teens Like It Black","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[79] = ["Racks and Blacks","Racks and Blacks","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[80] = ["Butts and Blacks","Butts and Blacks","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[81] = ["Brazzers","Brazzers","http://www.brazzers.com","http://www.brazzers.com/search/all/?q="]
searchSites[82] = ["X Art","X-Art","http://www.x-art.com","http://www.x-art.com/search/"]
searchSites[83] = ["Bang Bros","Bang Bros","https://bangbros.com","https://bangbros.com/search/"]
searchSites[84] = ["Ass Parade","Ass Parade","https://bangbros.com","https://bangbros.com/search/"]
searchSites[85] = ["AvaSpice","AvaSpice","https://bangbros.com","https://bangbros.com/search/"]
searchSites[86] = ["Back Room Facials","Back Room Facials","https://bangbros.com","https://bangbros.com/search/"]
searchSites[87] = ["Backroom MILF","Backroom MILF","https://bangbros.com","https://bangbros.com/search/"]
searchSites[88] = ["Ball Honeys","Ball Honeys","https://bangbros.com","https://bangbros.com/search/"]
searchSites[89] = ["Bang Bus","Bang Bus","https://bangbros.com","https://bangbros.com/search/"]
searchSites[90] = ["Bang Casting","Bang Casting","https://bangbros.com","https://bangbros.com/search/"]
searchSites[91] = ["Bang POV","Bang POV","https://bangbros.com","https://bangbros.com/search/"]
searchSites[92] = ["Bang Tryouts","Bang Tryouts","https://bangbros.com","https://bangbros.com/search/"]
searchSites[93] = ["BangBros 18","BangBros 18","https://bangbros.com","https://bangbros.com/search/"]
searchSites[94] = ["BangBros Angels","BangBros Angels","https://bangbros.com","https://bangbros.com/search/"]
searchSites[95] = ["Bangbros Clips","Bangbros Clips","https://bangbros.com","https://bangbros.com/search/"]
searchSites[96] = ["BangBros Remastered","BangBros Remastered","https://bangbros.com","https://bangbros.com/search/"]
searchSites[97] = ["Big Mouthfuls","Big Mouthfuls","https://bangbros.com","https://bangbros.com/search/"]
searchSites[98] = ["Big Tit Cream Pie","Big Tit Cream Pie","https://bangbros.com","https://bangbros.com/search/"]
searchSites[99] = ["Big Tits Round Asses","Big Tits Round Asses","https://bangbros.com","https://bangbros.com/search/"]
searchSites[100] = ["BlowJob Fridays","BlowJob Fridays","https://bangbros.com","https://bangbros.com/search/"]
searchSites[101] = ["Blowjob Ninjas","Blowjob Ninjas","https://bangbros.com","https://bangbros.com/search/"]
searchSites[102] = ["Boob Squad","Boob Squad","https://bangbros.com","https://bangbros.com/search/"]
searchSites[103] = ["Brown Bunnies","Brown Bunnies","https://bangbros.com","https://bangbros.com/search/"]
searchSites[104] = ["Can He Score","Can He Score","https://bangbros.com","https://bangbros.com/search/"]
searchSites[105] = ["Bang Casting","Bang Casting","https://bangbros.com","https://bangbros.com/search/"]
searchSites[106] = ["Chongas","Chongas","https://bangbros.com","https://bangbros.com/search/"]
searchSites[107] = ["Colombia Fuck Fest","Colombia Fuck Fest","https://bangbros.com","https://bangbros.com/search/"]
searchSites[108] = ["Dirty World Tour","Dirty World Tour","https://bangbros.com","https://bangbros.com/search/"]
searchSites[109] = ["Dorm Invasion","Dorm Invasion","https://bangbros.com","https://bangbros.com/search/"]
searchSites[110] = ["Facial Fest","Facial Fest","https://bangbros.com","https://bangbros.com/search/"]
searchSites[111] = ["Fuck Team Five","Fuck Team Five","https://bangbros.com","https://bangbros.com/search/"]
searchSites[112] = ["Glory Hole Loads","Glory Hole Loads","https://bangbros.com","https://bangbros.com/search/"]
searchSites[113] = ["Latina Rampage","Latina Rampage","https://bangbros.com","https://bangbros.com/search/"]
searchSites[114] = ["Living With Anna","Living With Anna","https://bangbros.com","https://bangbros.com/search/"]
searchSites[115] = ["Magical Feet","Magical Feet","https://bangbros.com","https://bangbros.com/search/"]
searchSites[116] = ["MILF Lessons","MILF Lessons","https://bangbros.com","https://bangbros.com/search/"]
searchSites[117] = ["Milf Soup","Milf Soup","https://bangbros.com","https://bangbros.com/search/"]
searchSites[118] = ["MomIsHorny","MomIsHorny","https://bangbros.com","https://bangbros.com/search/"]
searchSites[119] = ["Monsters of Cock","Monsters of Cock","https://bangbros.com","https://bangbros.com/search/"]
searchSites[120] = ["Mr CamelToe","Mr CamelToe","https://bangbros.com","https://bangbros.com/search/"]
searchSites[121] = ["Mr Anal","Mr Anal","https://bangbros.com","https://bangbros.com/search/"]
searchSites[122] = ["My Dirty Maid","My Dirty Maid","https://bangbros.com","https://bangbros.com/search/"]
searchSites[123] = ["My Life In Brazil","My Life In Brazil","https://bangbros.com","https://bangbros.com/search/"]
searchSites[124] = ["Newbie Black","Newbie Black","https://bangbros.com","https://bangbros.com/search/"]
searchSites[125] = ["Party of 3","Party of 3","https://bangbros.com","https://bangbros.com/search/"]
searchSites[126] = ["Pawg","Pawg","https://bangbros.com","https://bangbros.com/search/"]
searchSites[127] = ["Penny Show","Penny Show","https://bangbros.com","https://bangbros.com/search/"]
searchSites[128] = ["Porn Star Spa","Porn Star Spa","https://bangbros.com","https://bangbros.com/search/"]
searchSites[129] = ["Power Munch","Power Munch","https://bangbros.com","https://bangbros.com/search/"]
searchSites[130] = ["Public Bang","Public Bang","https://bangbros.com","https://bangbros.com/search/"]
searchSites[131] = ["Slutty White Girls","Slutty White Girls","https://bangbros.com","https://bangbros.com/search/"]
searchSites[132] = ["Stepmom Videos","Stepmom Videos","https://bangbros.com","https://bangbros.com/search/"]
searchSites[133] = ["Street Ranger","Street Ranger","https://bangbros.com","https://bangbros.com/search/"]
searchSites[134] = ["Tugjobs","Tugjobs","https://bangbros.com","https://bangbros.com/search/"]
searchSites[135] = ["Working Latinas","Working Latinas","https://bangbros.com","https://bangbros.com/search/"]
searchSites[136] = ["Tushy","Tushy","https://www.tushy.com","https://www.tushy.com/search?q="]
searchSites[137] = ["Reality Kings","Reality Kings", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[138] = ["40 Inch Plus", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[139] = ["8th Street Latinas","8th Street Latinas", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[140] = ["Bad Tow Truck","Bad Tow Truck", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[141] = ["Big Naturals","Big Naturals", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[142] = ["Big Tits Boss","Big Tits Boss", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[143] = ["Bikini Crashers","Bikini Crashers", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[144] = ["Captain Stabbin","Captain Stabbin", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[145] = ["CFNM Secret","CFNM Secret", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[146] = ["Cum Fiesta","Cum Fiesta", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[147] = ["Cum Girls","Cum Girls", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[148] = ["Dangerous Dongs","Dangerous Dongs", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[149] = ["Euro Sex Parties","Euro Sex Parties", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[150] = ["Extreme Asses","Extreme Asses", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[151] = ["Extreme Naturals","Extreme Naturals", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[152] = ["First Time Auditions","First Time Auditions", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[153] = ["Flower Tucci","Flower Tucci", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[154] = ["Girls of Naked","Girls of Naked", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[155] = ["Happy Tugs","Happy Tugs", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[156] = ["HD Love","HD Love", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[157] = ["Hot Bush","Hot Bush", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[158] = ["In the VIP","In the VIP", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[159] = ["Mike in Brazil","Mike in Brazil", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[160] = ["Mikes Apartment","Mike's Apartment", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[161] = ["Milf Hunter","Milf Hunter", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[162] = ["Milf Next Door","Milf Next Door", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[163] = ["Moms Bang Teens","Moms Bang Teens", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[164] = ["Moms Lick Teens","Moms Lick Teens", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[165] = ["Money Talks","Money Talks", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[166] = ["Monster Curves","Monster Curves", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[167] = ["No Faces","No Faces", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[168] = ["Pure 18","Pure 18", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[169] = ["Real Orgasms","Real Orgasms", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[170] = ["RK Prime","RK Prime", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[171] = ["Round and Brown","Round and Brown", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[172] = ["Saturday Night Latinas","Saturday Night Latinas", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[173] = ["See My Wife","See My Wife", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[174] = ["Sneaky Sex","Sneaky Sex", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[175] = ["Street BlowJobs","Street BlowJobs", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[176] = ["Team Squirt","Team Squirt", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[177] = ["Teens Love Huge Cocks","Teens Love Huge Cocks", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[178] = ["Top Shelf Pussy","Top Shelf Pussy", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[179] = ["Tranny Surprise","Tranny Surprise", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[180] = ["VIP Crew","VIP Crew", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[181] = ["We Live Together","We Live Together", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[182] = ["Wives in Pantyhose","Wives in Pantyhose", "https://www.realitykings.com/", "https://www.realitykings.com/tour/search/videos/"]
searchSites[183] = ["21Naturals","21Naturals","https://www.21naturals.com","http://www.21naturals.com/en/search/"]
searchSites[184] = ["PornFidelity","PornFidelity","https://www.pornfidelity.com","https://www.pornfidelity.com/episodes/search/?site=2&page=1&search="]
searchSites[185] = ["TeenFidelity","TeenFidelity","https://www.pornfidelity.com","https://www.pornfidelity.com/episodes/search/?site=3&page=1&search="]
searchSites[186] = ["Kelly Madison","Kelly Madison","https://www.pornfidelity.com","https://www.pornfidelity.com/episodes/search/?site=1&page=1&search="]
searchSites[187] = ["TeamSkeet", "TeamSkeet", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[188] = ["Exxxtra small","Exxxtra small", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[189] = ["Teen Pies","Teen Pies", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[190] = ["Innocent High","Innocent High", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[191] = ["Teen Curves","Teen Curves", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[192] = ["CFNM Teens","CFNM Teens", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[193] = ["Teens Love Anal","Teens Love Anal", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[194] = ["My Babysitters Club","My Babysitters Club", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[195] = ["Shes New","She's New", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[196] = ["Teens Do Porn","Teens Do Porn", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[197] = ["POV Life","POV Life", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[198] = ["The Real Workout","The Real Workout", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[199] = ["This Girl Sucks","This Girl Sucks", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[200] = ["Teens Love Money","Teens Love Money", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[201] = ["Oye Loca","Oye Loca", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[202] = ["Titty Attack","Titty Attack", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[203] = ["Teeny Black","Teeny Black", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[204] = ["Lust HD","Lust HD", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[205] = ["Rub A Teen","Rub A Teen", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[206] = ["Her Freshman Year","Her Freshman Year", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[207] = ["Self Desire","Self Desire", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[208] = ["Solo Interviews","Solo Interviews", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[209] = ["Team Skeet Extras","Team Skeet Extras", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[210] = ["Dyked","Dyked", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[211] = ["Badmilfs","Badmilfs", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[212] = ["Gingerpatch","Gingerpatch", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[213] = ["BraceFaced","BraceFaced", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[214] = ["TeenJoi","TeenJoi", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[215] = ["StepSiblings","StepSiblings", "https://www.teamskeet.com","https://www.teamskeet.com/t1/search/results/?query="]
searchSites[216] = ["Porndoe Premium","Porndoe Premium", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[217] = ["The White Boxxx","The White Boxxx", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[218] = ["Scam Angels","Scam Angels", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[219] = ["Chicas Loca","Chicas Loca", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[220] = ["Her Limit","Her Limit", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[221] = ["A Girl Knows","A Girl Knows", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[222] = ["Porno Academie","Porno Academie", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[223] = ["Xchimera","Xchimera", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[224] = ["Carne Del Mercado","Carne Del Mercado", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[225] = ["XXXShades","XXXShades", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[226] = ["BumsBus","BumsBus", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[227] = ["Bitches Abroad","Bitches Abroad", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[228] = ["La Cochonne","La Cochonne", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[229] = ["Crowd Bondage","Crowd Bondage", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[230] = ["Relaxxxed","Relaxxxed", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[231] = ["My Naughty Album","My Naughty Album", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[232] = ["Tu Venganza","Tu Venganza", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[233] = ["Bums Buero","Bums Buero", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[234] = ["Los Consoladores","Los Consoladores", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[235] = ["Quest for Orgasm","Quest for Orgasm", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[236] = ["Transbella","Transbella", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[237] = ["Her Big Ass","Her Big Ass", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[238] = ["Narcos X","Narcos X", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[239] = ["Fucked In Traffic","Fucked In Traffic", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[240] = ["Las Folladoras","Las Folladoras", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[241] = ["Badtime Stories","Badtime Stories", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[242] = ["Exposed Casting","Exposed Casting", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[243] = ["Kinky Inlaws","Kinky Inlaws", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[244] = ["Doe Projects","Doe Projects", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[245] = ["Porndoepedia","Porndoepedia", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[246] = ["Casting Francais","Casting Francais", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[247] = ["Bums Besuch","Bums Besuch", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[248] = ["Special Feet Force","Special Feet Force", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[249] = ["Trans Taboo","Trans Taboo", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[250] = ["Operacion Limpieza","Operacion Limpieza", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[251] = ["La Novice","La Novice", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[252] = ["Casting Alla Italiana","Casting Alla Italiana", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[253] = ["PinUp Sex","PinUp Sex", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[254] = ["Hausfrau Ficken","Hausfrau Ficken", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[255] = ["Deutchland Report","Deutchland Report", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[256] = ["Reife Swinger","Reife Swinger", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[257] = ["Scambisti Maturi","Scambisti Maturi", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[258] = ["STG","STG", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[259] = ["XXX Omas","XXX Omas", "https://porndoepremium.com","https://porndoepremium.com/videos?keywords="]
searchSites[260] = ["LegalPorno","LegalPorno","https://www.legalporno.com","https://www.legalporno.com/search/?query="]
searchSites[261] = ["Mofos","Mofos","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[262] = ["ShareMyBF","ShareMyBF","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[263] = ["Dont Break Me","Don't Break Me","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[264] = ["I Know That Girl","I Know That Girl","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[265] = ["Lets Try Anal","Let's Try Anal","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[266] = ["Pervs On Patrol","Pervs On Patrol","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[267] = ["Stranded Teens","Stranded Teens","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[268] = ["Mofos B Sides","Mofos B Sides","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[269] = ["Shes a Freak","She's a Freak","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[270] = ["Public Pickups","Public Pickups","https://www.mofos.com","https://www.mofos.com/tour/search/?q="]
searchSites[271] = ["Babes","Babes","https://www.babes.com","https://www.babes.com/tour/search/all/keyword/"]
searchSites[272] = ["Babes Unleashed","Babes Unleashed","https://www.babes.com","https://www.babes.com/tour/search/all/keyword/"]
searchSites[273] = ["Black is Better","Black is Better","https://www.babes.com","https://www.babes.com/tour/search/all/keyword/"]
searchSites[274] = ["Elegant Anal","Elegant Anal","https://www.babes.com","https://www.babes.com/tour/search/all/keyword/"]
searchSites[275] = ["Office Obsession","Office Obsession","https://www.babes.com","https://www.babes.com/tour/search/all/keyword/"]
searchSites[276] = ["Stepmom Lessons","Stepmom Lessons","https://www.babes.com","https://www.babes.com/tour/search/all/keyword/"]
searchSites[277] = ["Evil Angel","Evil Angel","https://www.evilangel.com","https://www.evilangel.com/en/search/"]
searchSites[278] = ["HardX","HardX","https://www.xempire.com","https://www.xempire.com/en/search/hardx/scene/"]
searchSites[279] = ["GloryHoleSecrets","GloryHoleSecrets","http://www.gloryholesecrets.com","http://www.gloryholesecrets.com/tour/search.php?query="]
searchSites[280] = ["New Sensations","New Sensations","http://www.newsensations.com","https://www.newsensations.com/tour_ns/search.php?query="]
searchSites[281] = ["Pure Taboo","Pure Taboo","https://www.puretaboo.com","https://www.puretaboo.com/en/search/"]
searchSites[282] = ["Swallowed","Swallowed","https://tour.swallowed.com","https://tour.swallowed.com/search/"]
searchSites[283] = ["TrueAnal","TrueAnal","https://tour.trueanal.com","https://tour.trueanal.com/search/"]
searchSites[284] = ["Nympho","Nympho","https://tour.nympho.com","https://tour.nympho.com/search/"]
searchSites[285] = ["EroticaX","EroticaX","https://www.xempire.com","https://www.xempire.com/en/search/eroticax/scene/"]
searchSites[286] = ["DarkX","DarkX","https://www.xempire.com","https://www.xempire.com/en/search/darkx/scene/"]
searchSites[287] = ["LesbianX","LesbianX","http://www.xempire.com","http://www.xempire.com/en/search/lesbianx/scene/"]
searchSites[288] = ["Twistys","Twistys","https://www.twistys.com","https://www.twistys.com/tour/search/list/keyword/?keyword="]
searchSites[289] = ["When Girls Play","When Girls Play","https://www.twistys.com","https://www.twistys.com/tour/search/list/keyword/?keyword="]
searchSites[290] = ["Mom Knows Best","Mom Knows Best","https://www.twistys.com","https://www.twistys.com/tour/search/list/keyword/?keyword="]
searchSites[291] = ["Twistys Hard","Twistys Hard","https://www.twistys.com","https://www.twistys.com/tour/search/list/keyword/?keyword="]
searchSites[292] = ["Replaced","Replaced","http://lubed.com","http://lubed.com/video/"]
searchSites[293] = ["Spizoo","Spizoo","https://www.spizoo.com","https://www.spizoo.com/search.php?query="]
searchSites[294] = ["Private","Private","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[295] = ["Anal Introductions","Anal Introductions","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[296] = ["Blacks on Sluts","Blacks on Sluts","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[297] = ["I confess Files","I confess Files","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[298] = ["Private Fetish","Private Fetish","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[299] = ["Mission Ass Possible","Mission Ass Possible","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[300] = ["Private MILFs","Private MILFs","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[301] = ["Russian Fake Agent","Russian Fake Agent","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[302] = ["Russian Teen Ass","Russian Teen Ass","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[303] = ["Sex on the beach","Sex on the beach","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[304] = ["Private Stars","Private Stars","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[305] = ["Tight and Teen","Tight and Teen","https://www.private.com","https://www.private.com/search.php?query="]
searchSites[306] = ["PassionHD","PassionHD","http://www.passion-hd.com","http://passion-hd.com/video/"]
searchSites[307] = ["FantasyHD","FantasyHD","http://www.fantasyhd.com","http://fantasyhd.com/video/"]
searchSites[308] = ["PornPros","PornPros","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[309] = ["18YearsOld","18YearsOld","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[310] = ["RealExGirlfriends","RealExGirlfriends","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[311] = ["MassageCreep","MassageCreep","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[312] = ["DeepThroatLove","DeepThroatLove","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[313] = ["TeenBFF","TeenBFF","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[314] = ["ShadyPi","ShadyPi","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[315] = ["CrueltyParty","CrueltyParty","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[316] = ["Disgraced18","Disgraced18","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[317] = ["MilfHumiliation","MilfHumiliation","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[318] = ["CumshotSurprise","CumshotSurprise","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[319] = ["40ozBounce","40ozBounce","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[320] = ["JurassicCock","JurassicCock","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[321] = ["FreaksOfCock","FreaksOfCock","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[322] = ["EuroHumpers","EuroHumpers","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[323] = ["FreaksOfBoobs","FreaksOfBoobs","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[324] = ["CumDisgrace","CumDisgrace","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[325] = ["CockCompetition","CockCompetition","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[326] = ["PimpParade","PimpParade","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[327] = ["SquirtDisgrace","SquirtDisgrace","http://www.pornpros.com","http://pornpros.com/video/"]
searchSites[328] = ["DigitalPlayground","DigitalPlayground","https://www.digitalplayground.com","https://www.digitalplayground.com/search/videos/"]
searchSites[329] = ["Throated","Throated","https://www.blowpass.com","https://www.blowpass.com/en/search/throated/scene/"]
searchSites[330] = ["Sweetheart Video","Sweetheart Video","https://www.milehighmedia.com","http://www.milehighmedia.com/en/search/"]
searchSites[331] = ["Nuru Massage","Nuru Massage","https://www.fantasymassage.com","https://www.fantasymassage.com/en/search/"]
searchSites[332] = ["SweetSinner","SweetSinner","https://www.milehighmedia.com","http://www.milehighmedia.com/en/search/"]
searchSites[333] = ["SexyHub","SexyHub","https://www.sexyhub.com","https://www.sexyhub.com/search/videos/"]
searchSites[334] = ["Dane Jones","Dane Jones","https://www.sexyhub.com","https://www.sexyhub.com/search/videos/"]
searchSites[335] = ["Fitness Rooms","Fitness Rooms","https://www.fitnessrooms.com","https://www.fitnessrooms.com/search/videos/"]
searchSites[336] = ["Girlfriends.xxx","Girlfriends.xxx","https://www.sexyhub.com","https://www.sexyhub.com/search/videos/"]
searchSites[337] = ["Lesbea","Lesbea","https://www.sexyhub.com","https://www.sexyhub.com/search/videos/"]
searchSites[338] = ["Massage Rooms","Massage Rooms","https://www.sexyhub.com","https://www.sexyhub.com/search/videos/"]
searchSites[339] = ["MomXXX","MomXXX","https://www.sexyhub.com","https://www.sexyhub.com/search/videos/"]
searchSites[340] = ["FakeHub","FakeHub","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[341] = ["Big Cock Bully","Big Cock Bully","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[342] = ["FILL THIS IN","FILL THIS IN","https://FILL THIS IN.com","https://FILL THIS IN.com/search?term="]
searchSites[343] = ["Analized","Analized","https://www.analized.com","https://analized.com/search.php?query="]
searchSites[344] = ["James Deen","James Deen","https://www.jamesdeen.com","https://jamesdeen.com/search.php?query="]
searchSites[345] = ["Twisted Visual","Twisted Visual","https://www.twistedvisual.com","https://twistedvisual.com/search.php?query="]
searchSites[346] = ["Only Prince","Only Prince","https://www.onlyprince.com","https://onlyprince.com/search.php?query="]
searchSites[347] = ["Bad Daddy POV","Bad Daddy POV","https://www.baddaddypov.com","https://baddaddypov.com/search.php?query="]
searchSites[348] = ["POV Perverts","POV Perverts","https://www.povperverts.net","https://povperverts.net/search.php?query="]
searchSites[349] = ["Pervert Gallery","Pervert Gallery","https://www.pervertgallery.com","https://pervertgallery.com/search.php?query="]
searchSites[350] = ["DTF Sluts","DTF Sluts","https://www.dtfsluts.com","https://dtfsluts.com/search.php?query="]
searchSites[351] = ["Mommy Blows Best","Mommy Blows Best","http://www.blowpass.com","http://www.blowpass.com/en/search/mommyblowsbest/scene/"]
searchSites[352] = ["Only Teen Blowjobs","Only Teen Blowjobs","http://www.blowpass.com","http://www.blowpass.com/en/search/onlyteenblowjobs/scene/"]
searchSites[353] = ["1000 Facials","1000 Facials","http://www.blowpass.com","http://www.blowpass.com/en/search/1000facials/scene/"]
searchSites[354] = ["Immoral Live","Immoral Live","http://www.blowpass.com","http://www.blowpass.com/en/search/immorallive/scene/"]
searchSites[355] = ["Fantasy Massage","Fantasy Massage","http://www.fantasymassage.com","http://www.fantasymassage.com/en/search/"]
searchSites[356] = ["All Girl Massage","All Girl Massage","http://www.fantasymassage.com","http://www.fantasymassage.com/en/search/"]
searchSites[357] = ["Soapy Massage","Soapy Massage","http://www.fantasymassage.com","http://www.fantasymassage.com/en/search/"]
searchSites[358] = ["Milking Table","Milking Table","http://www.fantasymassage.com","http://www.fantasymassage.com/en/search/"]
searchSites[359] = ["Massage Parlor","Massage Parlor","http://www.fantasymassage.com","http://www.fantasymassage.com/en/search/"]
searchSites[360] = ["Tricky Spa","Tricky Spa","http://www.fantasymassage.com","http://www.fantasymassage.com/en/search/"]
searchSites[361] = ["Cherry Pop","Cherry Pop","http://www.milehighmedia.com","http://www.milehighmedia.com/en/search/"]
searchSites[362] = ["Reality Junkies","Reality Junkies","http://www.milehighmedia.com","http://www.milehighmedia.com/en/search/"]
searchSites[363] = ["Lesbian Older Younger","Lesbian Older Younger","http://www.milehighmedia.com","http://www.milehighmedia.com/en/search/"]
searchSites[364] = ["Doghouse Digital","Doghouse Digital","http://www.milehighmedia.com","http://www.milehighmedia.com/en/search/"]
searchSites[365] = ["21Sextury","21Sextury","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[366] = ["Anal Teen Angels","Anal Teen Angels","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[367] = ["Deepthroat Frenzy","Deepthroat Frenzy","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[368] = ["DP Fanatics","DP Fanatics","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[369] = ["Footsie Babes","Footsie Babes","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[370] = ["Gapeland","Gapeland","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[371] = ["Lez Cuties","Lez Cuties","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[372] = ["Pix and Video","Pix and Video","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[373] = ["21FootArt","21FootArt","http://www.21naturals.com","http://www.21naturals.com/en/search/"]
searchSites[374] = ["21EroticAnal","21EroticAnal","http://www.21naturals.com","http://www.21naturals.com/en/search/"]
searchSites[375] = ["Mommys Girl","Mommy's Girl","http://www.girlsway.com","http://www.girlsway.com/en/search/"]
searchSites[376] = ["Web Young","Web Young","http://www.girlsway.com","http://www.girlsway.com/en/search/"]
searchSites[377] = ["Girls Try Anal","Girls Try Anal","http://www.girlsway.com","http://www.girlsway.com/en/search/"]
searchSites[378] = ["Sextape Lesbians","Sextape Lesbians","http://www.girlsway.com","http://www.girlsway.com/en/search/"]
searchSites[379] = ["Girlsway Originals","Girlsway Originals","http://www.girlsway.com","http://www.girlsway.com/en/search/"]
searchSites[380] = ["Girlfriends Films","Girlfriends Films","http://www.girlfriendsfilms.com","http://www.girlfriendsfilms.com/en/search/"]
searchSites[381] = ["Burning Angel","Burning Angel","http://www.burningangel.com","http://www.burningangel.com/en/search/"]
searchSites[382] = ["Pretty Dirty","Pretty Dirty","http://www.prettydirty.com","http://www.prettydirty.com/en/search/"]
searchSites[383] = ["Devils Film","Devil's Film","http://www.devilsfilm.com","http://www.devilsfilm.com/en/search/"]
searchSites[384] = ["Peter North","Peter North","http://www.peternorth.com","http://www.peternorth.com/en/search/"]
searchSites[385] = ["Rocco Siffredi","Rocco Siffredi","http://www.roccosiffredi.com","http://www.roccosiffredi.com/en/search/"]
searchSites[386] = ["Tera Patrick","Tera Patrick","http://www.terapatrick.com","http://www.terapatrick.com/en/search/"]
searchSites[387] = ["Sunny Leone","Sunny Leone","http://www.sunnyleone.com","http://www.sunnyleone.com/en/search/scene/"]
searchSites[388] = ["Lane Sisters","Lane Sisters","http://www.lanesisters.com","http://www.lanesisters.com/en/search/scene/"]
searchSites[389] = ["Dylan Ryder","Dylan Ryder","http://www.dylanryder.com","http://www.dylanryder.com/en/search/scene/"]
searchSites[390] = ["Abbey Brooks","Abbey Brooks","http://www.abbeybrooks.com","http://www.abbeybrooks.com/en/search/scene/"]
searchSites[391] = ["Devon Lee","Devon Lee","http://www.devonlee.com","http://www.devonlee.com/en/search/scene/"]
searchSites[392] = ["Hanna Hilton","Hanna Hilton","http://www.hannahilton.com","http://www.hannahilton.com/en/search/scene/"]
searchSites[393] = ["LA Sluts","LA Sluts","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[394] = ["Slut Stepsister","Slut Stepsister","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[395] = ["Teens Love Cream","Teens Love Cream","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[396] = ["Latina Stepmom","Latina Stepmom","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[397] = ["Fake Taxi","Fake Taxi","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[398] = ["Fakehub Originals","Fakehub Originals","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[399] = ["Public Agent","Public Agent","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[400] = ["Fake Agent","Fake Agent","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[401] = ["Female Agent","Female Agent","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[402] = ["Fake Hospital","Fake Hospital","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[403] = ["Fake Agent UK","Fake Agent UK","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[404] = ["Fake Cop","Fake Cop","https://www.fakehub.com","https://www.fakehub.com/search/videos/"]
searchSites[405] = ["Female Fake Taxi","Female Fake Taxi","https://www.femalefaketaxi.com","https://www.femalefaketaxi.com/search/videos/"]
searchSites[406] = ["Fake Driving School","Fake Driving School","https://www.fakedrivingschool.com","https://www.fakedrivingschool.com/search/videos/"]
searchSites[407] = ["Fake Hostel","Fake Hostel","https://www.fakehostel.com","https://www.fakehostel.com/search/videos/"]
searchSites[408] = ["Dogfart","Dogfart","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[409] = ["BlacksOnBlondes","Blacks On Blondes","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[410] = ["CuckoldSessions","Cuckold Sessions","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[411] = ["GloryHole","Glory Hole","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[412] = ["BlacksOnCougars","Blacks On Cougars","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[413] = ["WeFuckBlackGirls","WeFuckBlackGirls","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[414] = ["WatchingMyMomGoBlack","WatchingMyMomGoBlack","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[415] = ["InterracialBlowbang","Interracial Blowbang","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[416] = ["CumBang","CumBang","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[417] = ["InterracialPickups","Interracial Pickups","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[418] = ["WatchingMyDaughterGoBlack","WatchingMyDaughterGoBlack","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[419] = ["ZebraGirls","ZebraGirls","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[420] = ["GloryHoleInitiations","GloryHoleInitiations","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[421] = ["DogfartBehindTheScenes","DogfartBehindTheScenes","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[422] = ["BlackMeatWhiteFeet","BlackMeatWhiteFeet","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[423] = ["SpringThomas","SpringThomas","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[424] = ["KatieThomas","KatieThomas","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[425] = ["RuthBlackwell","RuthBlackwell","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[426] = ["CandyMonroe","CandyMonroe","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[427] = ["WifeWriting","WifeWriting","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[428] = ["BarbCummings","BarbCummings","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[429] = ["TheMinion","TheMinion","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[430] = ["BlacksOnBoys","BlacksOnBoys","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[431] = ["GloryholesAndHandjobs","GloryholesAndHandjobs","https://www.dogfartnetwork.com","https://www.dogfartnetwork.com/tour/search.php?search="]
searchSites[432] = ["Jules Jordan","Jules Jordan", "https://www.julesjordan.com","https://www.julesjordan.com/trial/search.php?query="]
searchSites[433] = ["DDFNetwork","DDFNetwork", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[434] = ["Hands on Hardcore","Hands on Hardcore", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[435] = ["DDF Busty","DDF Busty", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[436] = ["House of Taboo","House of Taboo", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[437] = ["Euro Girls on Girls","Euro Girls on Girls", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[438] = ["1By-Day","1By-Day", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[439] = ["DDF Network VR","DDF Network VR", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[440] = ["Euro Teen Erotica","Euro Teen Erotica", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[441] = ["Hot Legs and Feet","Hot Legs & Feet", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[442] = ["Only Blowjob","Only Blowjob", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[443] = ["Sandys Fantasies","Sandy's Fantasies", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[444] = ["Cherry Jul","Cherry Jul", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[445] = ["Eve Angel Official","Eve Angel Official", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[446] = ["Sex Video Casting","Sex Video Casting", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[447] = ["Hairy Twatter","Hairy Twatter", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/"]
searchSites[448] = ["PerfectGonzo","PerfectGonzo", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?q="]
searchSites[449] = ["AllInternal","AllInternal", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=allinternal&q="]
searchSites[450] = ["AssTraffic","AssTraffic", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=asstraffic&q="]
searchSites[451] = ["CumForCover","CumForCover", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=cumforcover&q="]
searchSites[452] = ["Primecups","Primecups", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=primecups&q="]
searchSites[453] = ["PurePOV","PurePOV", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=purepov&q="]
searchSites[454] = ["SpermSwap","SpermSwap", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=spermaswap&q="]
searchSites[455] = ["TamedTeens","TamedTeens", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=tamedteens&q="]
searchSites[456] = ["GiveMePink","GiveMePink", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=givemepink&q="]
searchSites[457] = ["FistFlush","FistFlush", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=fistflush&q="]
searchSites[458] = ["MilfThing","MilfThing", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=milfthing&q="]
searchSites[459] = ["PerfectGonzoInterview","PerfectGonzoInterview", "https://www.perfectgonzo.com","https://www.perfectgonzo.com/movies?tag=interview&q="]
searchSites[460] = ["21Sextreme","21Sextreme","http://www.21sextreme.com","http://www.21sextreme.com/en/search/"]
searchSites[461] = ["LustyGrandmas","LustyGrandmas","http://www.21sextreme.com","http://www.21sextreme.com/en/search/"]
searchSites[462] = ["GrandpasFuckTeens","GrandpasFuckTeens","http://www.21sextreme.com","http://www.21sextreme.com/en/search/"]
searchSites[463] = ["TeachMeFisting","TeachMeFisting","http://www.21sextreme.com","http://www.21sextreme.com/en/search/"]
searchSites[464] = ["Zoliboy","Zoliboy","http://www.21sextreme.com","http://www.21sextreme.com/en/search/"]
searchSites[465] = ["DominatedGirls","DominatedGirls","http://www.21sextreme.com","http://www.21sextreme.com/en/search/"]
searchSites[466] = ["Asshole Fever","Asshole Fever","http://www.21sextury.com","http://www.21sextury.com/en/search/"]
searchSites[467] = ["Anal College","Anal College","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[468] = ["Watch Your Wife","Watch Your Wife","https://tour.naughtyamerica.com","https://tour.naughtyamerica.com/search?term="]
searchSites[469] = ["BadoinkVR","BadoinkVR","https://www.badoinkvr.com","https://badoinkvr.com/vrpornvideo/"]
searchSites[470] = ["BabeVR","BabeVR","https://www.babevr.com","https://babevr.com/vrpornvideo/"]
searchSites[471] = ["18VR","18VR","https://www.18vr.com","https://18vr.com/vrpornvideo/"]
searchSites[472] = ["KinkVR","KinkVR","http://www.kinkvr.com","https://kinkvr.com/bdsm-vr-video/"]
searchSites[473] = ["VRCosplayX","VRCosplayX","https://www.vrcosplayx.com","https://vrcosplayx.com/cosplaypornvideo/"]
searchSites[474] = ["VRBangers","VRBangers","https://www.vrbangers.com","https://vrbangers.com/video/"]
searchSites[475] = ["SexBVR","SexBabesVR","https://www.sexbabesvr.com","https://sexbabesvr.com/virtualreality/scene/id/"] #typo purposeful to avoid detection as babes.com
searchSites[476] = ["WankzVR","WankzVR","https://www.wankzvr.com","https://www.wankzvr.com/search?q="]
searchSites[477] = ["MilfVR","MilfVR","https://www.milfvr.com","https://www.milfvr.com/search?q="]
searchSites[478] = ["Joymii","Joymii","https://www.joymii.com","https://www.joymii.com/search?query="]
searchSites[479] = ["POVD","POVD","http://www.povd.com","http://povd.com/video/"]
searchSites[480] = ["Cum4K","Cum4K","http://www.cum4k.com","http://cum4k.com/video/"]
searchSites[481] = ["Exotic4k","Exotic4k","http://www.exotic4k.com","http://exotic4k.com/video/"]
searchSites[482] = ["Tiny4k","Tiny4k","http://www.tiny4k.com","http://tiny4k.com/video/"]
searchSites[483] = ["Lubed","Lubed","http://www.lubed.com","http://lubed.com/video/"]
searchSites[484] = ["PureMature","PureMature","http://www.puremature.com","http://puremature.com/video/"]
searchSites[485] = ["NannySpy","NannySpy","https://www.nannyspy.com","https://nannyspy.com/video/"]
searchSites[486] = ["Holed","Holed","https://www.holed.com","https://holed.com/video/"]
searchSites[487] = ["CastingCouch-X","CastingCouch-X","https://www.castingcouch-x.com","https://castingcouch-x.com/video/"]
searchSites[488] = ["SpyFam","SpyFam","https://www.spyfam.com","https://spyfam.com/video/"]
searchSites[489] = ["MyVeryFirstTime","MyVeryFirstTime","https://www.myveryfirsttime.com","https://myveryfirsttime.com/video/"]
searchSites[490] = ["Kink.com","Kink.com","http://www.kink.com","http://www.kink.com/search?q="]
searchSites[491] = ["Brutal Sessions","Brutal Sessions","http://www.kink.com","http://www.kink.com/search?channelIds=brutalsessions&q="]
searchSites[492] = ["Device Bondage","Device Bondage","http://www.kink.com","http://www.kink.com/search?channelIds=devicebondage&q="]
searchSites[493] = ["Families Tied","Families Tied","http://www.kink.com","http://www.kink.com/search?channelIds=familiestied&q="]
searchSites[494] = ["Hardcore Gangbang","Hardcore Gangbang","http://www.kink.com","http://www.kink.com/search?channelIds=hardcoregangbang&q="]
searchSites[495] = ["Hogtied","Hogtied","http://www.kink.com","http://www.kink.com/search?channelIds=hogtied&q="]
searchSites[496] = ["Kink Features","Kink Features","http://www.kink.com","http://www.kink.com/search?channelIds=kinkfeatures&q="]
searchSites[497] = ["Kink University","Kink University","http://www.kink.com","http://www.kink.com/search?channelIds=kinkuniversity&q="]
searchSites[498] = ["Public Disgrace","Public Disgrace","http://www.kink.com","http://www.kink.com/search?channelIds=publicdisgrace&q="]
searchSites[499] = ["Sadistic Rope","Sadistic Rope","http://www.kink.com","http://www.kink.com/search?channelIds=sadisticrope&q="]
searchSites[500] = ["Sex and Submission","Sex and Submission","http://www.kink.com","http://www.kink.com/search?channelIds=sexandsubmission&q="]
searchSites[501] = ["The Training of O","The Training of O","http://www.kink.com","http://www.kink.com/search?channelIds=thetrainingofo&q="]
searchSites[502] = ["The Upper Floor","The Upper Floor","http://www.kink.com","http://www.kink.com/search?channelIds=theupperfloor&q="]
searchSites[503] = ["Water Bondage","Water Bondage","http://www.kink.com","http://www.kink.com/search?channelIds=waterbondage&q="]
searchSites[504] = ["Everything Butt","Everything Butt","http://www.kink.com","http://www.kink.com/search?channelIds=everythingbutt&q="]
searchSites[505] = ["Foot Worship","Foot Worship","http://www.kink.com","http://www.kink.com/search?channelIds=footworship&q="]
searchSites[506] = ["Fucking Machines","Fucking Machines","http://www.kink.com","http://www.kink.com/search?channelIds=fuckingmachines&q="]
searchSites[507] = ["TS Pussy Hunters","TS Pussy Hunters","http://www.kink.com","http://www.kink.com/search?channelIds=tspussyhunters&q="]
searchSites[508] = ["TS Seduction","TS Seduction","http://www.kink.com","http://www.kink.com/search?channelIds=tsseduction&q="]
searchSites[509] = ["Ultimate Surrender","Ultimate Surrender","http://www.kink.com","http://www.kink.com/search?channelIds=ultimatesurrender&q="]
searchSites[510] = ["30 Minutes of Torment","30 Minutes of Torment","http://www.kink.com","http://www.kink.com/search?channelIds=30minutesoftorment&q="]
searchSites[511] = ["Bound Gods","Bound Gods","http://www.kink.com","http://www.kink.com/search?channelIds=boundgods&q="]
searchSites[512] = ["Bound in Public","Bound in Public","http://www.kink.com","http://www.kink.com/search?channelIds=boundinpublic&q="]
searchSites[513] = ["Butt Machine Boys","Butt Machine Boys","http://www.kink.com","http://www.kink.com/search?channelIds=buttmachineboys&q="]
searchSites[514] = ["Men on Edge","Men on Edge","http://www.kink.com","http://www.kink.com/search?channelIds=menonedge&q="]
searchSites[515] = ["Naked Kombat","Naked Kombat","http://www.kink.com","http://www.kink.com/search?channelIds=nakedkombat&q="]
searchSites[516] = ["Divine Bitches","Divine Bitches","http://www.kink.com","http://www.kink.com/search?channelIds=divinebitches&q="]
searchSites[517] = ["Electrosluts","Electrosluts","http://www.kink.com","http://www.kink.com/search?channelIds=electrosluts&q="]
searchSites[518] = ["Men in Pain","Men In Pain","http://www.kink.com","http://www.kink.com/search?channelIds=meninpain&q="]
searchSites[519] = ["Whipped Ass","Whipped Ass","http://www.kink.com","http://www.kink.com/search?channelIds=whippedass&q="]
searchSites[520] = ["Wired Pussy","Wired Pussy","http://www.kink.com","http://www.kink.com/search?channelIds=wiredpussy&q="]
searchSites[521] = ["Bound Gang Bangs","Bound Gang Bangs","http://www.kink.com","http://www.kink.com/search?channelIds=boundgangbangs&q="]
searchSites[522] = ["Manuel Ferrara","Manuel Ferrara", "https://www.manuelferrara.com","https://www.manuelferrara.com/trial/search.php?query="]
searchSites[523] = ["The Ass Factory","The Ass Factory", "https://www.theassfactory.com","https://www.theassfactory.com/trial/search.php?query="]
searchSites[524] = ["Sperm Swallowers","Sperm Swallowers", "https://www.spermswallowers.com","https://www.spermswallowers.com/trial/search.php?query="]
searchSites[525] = ["Nubile Films", "Nubile Films", "https://nubilefilms.com","https://nubilefilms.com/video/watch/" ]
searchSites[526] = ["Nubiles Porn", "Nubiles Porn", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[527] = ["Step Siblings Caught", "Step Siblings Caught", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[528] = ["Moms Teach Sex", "Moms Teach Sex", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[529] = ["Bad Teens Punished", "Bad Teens Punished", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[530] = ["Princess Cum", "Princess Cum", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[531] = ["Nubiles Unscripted", "Nubiles Unscripted", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[532] = ["Nubiles Casting", "Nubiles Casting", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/"]
searchSites[533] = ["Petite HD Porn", "Petite HD Porn", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[534] = ["Driver XXX", "Driver XXX", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[535] = ["Petite Ballerinas Fucked", "Petite Ballerinas Fucked", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[536] = ["Teacher Fucks Teens", "Teacher Fucks Teens", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[537] = ["Bountyhunter Porn", "Bountyhunter Porn", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[538] = ["Daddys Lil Angel", "Daddys Lil Angel", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[539] = ["My Family Pies", "My Family Pies", "https://nubiles-porn.com","https://nubiles-porn.com/video/watch/" ]
searchSites[540] = ["Nubiles", "Nubiles", "https://nubiles.net","https://nubiles.net/video/watch/" ]
searchSites[541] = ["Bratty Sis", "Bratty Sis", "https://brattysis.com","https://brattysis.com/video/watch/" ]
searchSites[542] = ["Anilos", "Anilos", "https://anilos.com","https://anilos.com/video/watch/" ]
searchSites[543] = ["Hot Crazy Mess", "Hot Crazy Mess", "https://hotcrazymess.com","https://hotcrazymess.com/video/watch/" ]
searchSites[544] = ["NF Busty", "NF Busty", "https://nfbusty.com","https://nfbusty.com/video/watch/" ]
searchSites[545] = ["That Sitcom Show", "That Sitcom Show", "https://thatsitcomporn.com","https://thatsitcomporn.com/video/watch/" ]
searchSites[546] = ["DDF Xtreme", "DDF Xtreme", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/" ]
searchSites[547] = ["DDF Hardcore", "DDF Hardcore", "https://ddfnetwork.com","https://ddfnetwork.com/videos/freeword/" ]

def getSearchBaseURL(siteID):
    return searchSites[siteID][2]
def getSearchSearchURL(siteID):
    return searchSites[siteID][3]
def getSearchFilter(siteID):
    return searchSites[siteID][0]
def getSearchSiteName(siteID):
    return searchSites[siteID][1]
def getSearchSiteIDByFilter(searchFilter):
    searchID = 0
    for sites in searchSites:
        # Might try converting this code to use startswith() to avoid problems with overlapping site names:
        # https://www.tutorialspoint.com/python/string_startswith.htm
        # Examples:
        #  Blacked -> BlackedRaw
        #  Babes -> FootsieBabes
        #  PassionHD Love Ties -> HD Love
        if sites[0].lower().replace(" ","").replace("'","") in searchFilter.lower().replace(".com","").replace("'","") or sites[0].lower().replace(" ","").replace("'","") in searchFilter.lower().replace(".com","").replace(" ","").replace("'",""):
            return searchID
        searchID += 1
    return 9999
def getSearchSettings(mediaTitle):
    mediaTitle = mediaTitle.replace(".", " ")
    mediaTitle = mediaTitle.replace(" - ", " ")
    mediaTitle = mediaTitle.replace("-", " ")

    # Search Site abbreviations
    # Using Regex instead of .replace or .startswith so it can be case insensitive
    mediaTitle = re.sub('bblib ', 'Big Butts Like It Big ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('btaw ', 'Big Tits at Work ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('btas ', 'Big Tits at School ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('btis ', 'Big Tits in Sports', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('plib ', 'Pornstars Like it Big', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('tuf ', 'The Upper Floor ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('wa ', 'Whipped Ass ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('fm ', 'Fucking Machines ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('^ht ', 'Hogtied ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('fho ', 'Fakehub Originals ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('fhl ', 'Fake Hostel ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('pba ', 'Public Agent ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('frs ', 'Fitness Rooms ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('fds ', 'Fake Driving School ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('fft ', 'Female Fake Taxi ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('mts ', 'Moms Teach Sex ', mediaTitle, flags=re.IGNORECASE)
    mediaTitle = re.sub('hoh ', 'HandsOnHardcore ', mediaTitle, flags=re.IGNORECASE)
    
    # Search Site ID of 9999 is all
    searchSiteID = None
    # Date/Actor or Title
    searchType = None
    # What to search for
    searchTitle = None
    # Date search
    searchDate = None
    # Actors search
    searchActors = None

    # Remove Site from Title
    searchSiteID = getSearchSiteIDByFilter(mediaTitle)
    Log("^^^^^^^ siteID: " + str(searchSiteID))
    if searchSiteID != 9999:
        Log("^^^^^^^ Shortening Title")
        Log(mediaTitle[:len(searchSites[searchSiteID][0])].lower() + " vs " + searchSites[searchSiteID][0].lower())
        if mediaTitle[:len(searchSites[searchSiteID][0])].lower() == searchSites[searchSiteID][0].lower():
            searchTitle = mediaTitle[len(searchSites[searchSiteID][0])+1:]
            Log("1")
        else:
            searchTitle = mediaTitle
            Log("2")
            if mediaTitle[:len(searchSites[searchSiteID][0].replace(" ",""))].lower() == searchSites[searchSiteID][0].lower().replace(" ",""):
                searchTitle = mediaTitle[len(searchSites[searchSiteID][0].replace(" ",""))+1:]
                Log("3")
            else:
                searchTitle = mediaTitle
                Log("4")
        if searchTitle[:4].lower() == "com ":
            searchTitle = searchTitle[4:]
            Log("5")
        Log("6")
    else:
        searchTitle = mediaTitle

    # Babes site search doesn't seem to handle words with apostrophes very well, so let's strip those words out
    if searchSiteID >= 271 and searchSiteID <= 276:
        words = searchTitle.split(" ")
        searchTitle = ""
        for word in words:
            if "'" not in word:
                searchTitle = searchTitle + word + " "

    Log("searchTitle (before date processing): " + searchTitle)
    #Search Type
    if unicode(searchTitle[:4], 'utf-8').isnumeric():
        if unicode(searchTitle[5:7], 'utf-8').isnumeric():
            if unicode(searchTitle[8:10], 'utf-8').isnumeric():
                searchType = 1
                searchDate = searchTitle[0:10].replace(" ","-")
                searchTitle = searchTitle[11:]
            else:
                searchType = 0
        else:
            searchType = 0
    else:
        if unicode(searchTitle[:2], 'utf-8').isnumeric():
            if unicode(searchTitle[3:5], 'utf-8').isnumeric():
                if unicode(searchTitle[6:8], 'utf-8').isnumeric():
                    searchType = 1
                    searchDate = "20" + searchTitle[0:8].replace(" ","-")
                    searchTitle = searchTitle[9:]
                else:
                    searchType = 0
            else:
                searchType = 0
        else:
            searchType = 0

    return [searchSiteID,searchType,searchTitle,searchDate]

def posterAlreadyExists(posterUrl,metadata):
    for p in metadata.posters.keys():
        Log(p.lower())
        if p.lower() == posterUrl.lower():
            Log("Found " + posterUrl + " in posters collection")
            return True

    for p in metadata.art.keys():
        if p.lower() == posterUrl.lower():
            return True
    return False